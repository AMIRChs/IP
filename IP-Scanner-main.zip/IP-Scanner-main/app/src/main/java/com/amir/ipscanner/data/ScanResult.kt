package com.amir.ipscanner.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLSocketFactory

// مدل داده برای ذخیره نتیجه اسکن هر آی‌پی
data class ScanResult(
    val ip: String,
    val isClean: Boolean,
    val latency: Long,
    val details: String
)

class NetworkRepository {

    // متد اصلی اسکن ضد فیک‌پینگ (ترکیب سوکت، TLS و سرویس واقعی)
    suspend fun scanIp(
        ip: String,
        port: Int,
        timeout: Int,
        vlessUuid: String?
    ): ScanResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            if (!vlessUuid.isNullOrBlank()) {
                // اگر کانفیگ VLESS وارد شده باشد، هندشیک پروتکل را تست کن
                val success = performVlessHandshake(ip, port, vlessUuid, timeout)
                val latency = System.currentTimeMillis() - startTime
                return@withContext ScanResult(ip, success, latency, if (success) "VLESS Handshake Success" else "VLESS Failed")
            } else {
                // در غیر این صورت، تست واقعی HTTP HEAD برای بررسی روتینگ واقعی داده‌ها
                val success = performRealHttpTest(ip, port, timeout)
                val latency = System.currentTimeMillis() - startTime
                return@withContext ScanResult(ip, success, latency, if (success) "HTTP Verification Success" else "Fake Response Detected")
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            return@withContext ScanResult(ip, false, latency, e.localizedMessage ?: "Timeout/Error")
        }
    }

    // تست متد HTTP HEAD برای اطمینان از بازگشت دیتای واقعی از CDN
    private fun performRealHttpTest(ip: String, port: Int, timeout: Int): Boolean {
        val client = OkHttpClient.Builder()
            .connectTimeout(timeout.toLong(), TimeUnit.MILLISECONDS)
            .readTimeout(timeout.toLong(), TimeUnit.MILLISECONDS)
            .sslSocketFactory(
                SSLSocketFactory.getDefault() as SSLSocketFactory,
                @Suppress("CustomX509TrustManager") 
                object : javax.net.ssl.X509TrustManager {
                    override fun checkClientTrusted(p0: Array<out java.security.cert.X509Certificate>?, p1: String?) {}
                    override fun checkServerTrusted(p0: Array<out java.security.cert.X509Certificate>?, p1: String?) {}
                    override fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate> = arrayOf()
                }
            )
            .hostnameVerifier { _, _ -> true } // دور زدن مچ نبودن دامنه با آی‌پی خام در مرحله تست
            .build()

        val protocol = if (port == 443 || port == 8443 || port == 2053) "https" else "http"
        // استفاده از یک هاست معتبر مثل کلودفلر برای گرفتن هدر پاسخ واقعی
        val request = Request.Builder()
            .url("$protocol://$ip:$port/")
            .header("Host", "www.cloudflare.com")
            .head() 
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                // اگر پاسخ برگشت، یعنی دیتا واقعا مسیردهی شده و فیک پینگ نیست
                response.code < 500
            }
        } catch (e: Exception) {
            false
        }
    }

    // شبیه‌سازی سبک هندشیک پروتکل VLESS روی سوکت خام برای تایید اصالت کانکشن
    private fun performVlessHandshake(ip: String, port: Int, uuidStr: String, timeout: Int): Boolean {
        var socket: Socket? = null
        try {
            val uuid = UUID.fromString(uuidStr.trim())
            socket = Socket()
            socket.connect(InetSocketAddress(ip, port), timeout)
            socket.soTimeout = timeout

            val outputStream = socket.getOutputStream()
            
            // ساخت پکت بسیار سبک دست‌تکانی VLESS (نسخه 0)
            val buffer = ByteArray(20)
            buffer[0] = 0x00 // Protocol Version 0
            
            // کپی کردن ۱۶ بایت UUID در پکت
            val msb = uuid.mostSignificantBits
            val lsb = uuid.leastSignificantBits
            for (i in 0..7) {
                buffer[1 + i] = (msb ushr (56 - i * 8)).toByte()
                buffer[9 + i] = (lsb ushr (56 - i * 8)).toByte()
            }
            buffer[17] = 0x00 // Addons length
            buffer[18] = 0x01 // Command: TCP
            buffer[19] = 0x00 // Port (Dummy/Handshake indicator)

            outputStream.write(buffer)
            outputStream.flush()

            // اگر سوکت بدون خطا بنویسد و بسته نشود، تایید اولیه انجام شده است
            return !socket.isClosed
        } catch (e: Exception) {
            return false
        } finally {
            runCatching { socket?.close() }
        }
    }
}
