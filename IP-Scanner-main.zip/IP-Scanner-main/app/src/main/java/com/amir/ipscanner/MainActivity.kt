package com.amir.ipscanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.amir.ipscanner.ui.AppLanguage
import com.amir.ipscanner.ui.Localization
import com.amir.ipscanner.ui.ScannerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScannerScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScannerScreen(viewModel: ScannerViewModel = viewModel()) {
    var language by remember { mutableStateOf(AppLanguage.FA) }
    val layoutDirection = if (language == AppLanguage.FA) LayoutDirection.Rtl else LayoutDirection.Ltr

    // متغیرهای فیلدهای ورودی
    var ipInput by remember { mutableStateOf("104.16.0.1, 172.67.1.1/24") }
    var portInput by remember { mutableStateOf("443") }
    var timeoutInput by remember { mutableStateOf("1500") }
    var vlessInput by remember { mutableStateOf("") }

    val scanResults by viewModel.scanResults.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val progress by viewModel.progress.collectAsState()

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(Localization.get("title", language), fontWeight = FontWeight.Bold) },
                    actions = {
                        Button(onClick = {
                            language = if (language == AppLanguage.EN) AppLanguage.FA else AppLanguage.EN
                        }) {
                            Text(if (language == AppLanguage.EN) "FA" else "EN")
                        }
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // فیلدهای تنظیمات اسکنر
                OutlinedTextField(
                    value = ipInput,
                    onValueChange = { ipInput = it },
                    label = { Text(Localization.get("ip_range", language)) },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = portInput,
                        onValueChange = { portInput = it },
                        label = { Text(Localization.get("port", language)) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = timeoutInput,
                        onValueChange = { timeoutInput = it },
                        label = { Text(Localization.get("timeout", language)) },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = vlessInput,
                    onValueChange = { vlessInput = it },
                    label = { Text(Localization.get("vless_config", language)) },
                    modifier = Modifier.fillMaxWidth()
                )

                // دکمه کنترل اسکن
                Button(
                    onClick = {
                        if (isScanning) {
                            viewModel.stopScan()
                        } else {
                            viewModel.startScan(
                                ipInput,
                                portInput.toIntOrNull() ?: 443,
                                timeoutInput.toIntOrNull() ?: 1500,
                                vlessInput.ifBlank { null }
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isScanning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(
                        text = if (isScanning) Localization.get("stop", language) else Localization.get("scan", language),
                        fontWeight = FontWeight.Bold
                    )
                }

                // نوار پیشرفت انیمیشنی
                AnimatedVisibility(visible = isScanning, enter = fadeIn(), exit = fadeOut()) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp)),
                    )
                }

                Text(
                    text = Localization.get("results", language),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp)
                )

                // لیست نمایش آی‌پی‌های تایید شده و خروجی نهایی
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(scanResults) { result ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(result.ip, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                Text(result.details, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = if (result.isClean) Localization.get("clean", language) else Localization.get("failed", language),
                                    color = if (result.isClean) Color(0xFF4CAF50) else Color(0xFFF44336),
                                    fontWeight = FontWeight.Bold
                                )
                                Text("${result.latency} ms", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
