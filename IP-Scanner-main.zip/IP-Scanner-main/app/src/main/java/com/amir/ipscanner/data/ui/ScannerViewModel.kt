package com.amir.ipscanner.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.amir.ipscanner.data.NetworkRepository
import com.amir.ipscanner.data.ScanResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ScannerViewModel : ViewModel() {
    private val repository = NetworkRepository()

    private val _scanResults = MutableStateFlow<List<ScanResult>>(emptyList())
    val scanResults: StateFlow<List<ScanResult>> = _scanResults

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress

    private var scanJob: Job? = null

    fun startScan(ipInput: String, port: Int, timeout: Int, vlessUuid: String?) {
        scanJob?.cancel()
        _scanResults.value = emptyList()
        _isScanning.value = true
        _progress.value = 0f

        // پارس کردن آی‌پی‌های ورودی (پشتیبانی از سابنت ساده یا کاما)
        val ipList = parseIpInput(ipInput)
        if (ipList.isEmpty()) {
            _isScanning.value = false
            return
        }

        scanJob = viewModelScope.launch {
            val total = ipList.size
            var completed = 0

            // اجرای اسکن همزمان (Concurrency) با کنترل تعداد جاب‌های موازی روی Coroutineها
            ipList.forEach { ip ->
                launch {
                    val result = repository.scanIp(ip, port, timeout, vlessUuid)
                    synchronized(_scanResults) {
                        _scanResults.value = _scanResults.value + result
                        completed++
                        _progress.value = completed.toFloat() / total
                    }
                }
            }
            // منتظر تمام شدن تمام کورتین‌های فرزند بمان
            scanJob?.join()
            _isScanning.value = false
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        _isScanning.value = false
    }

    private fun parseIpInput(input: String): List<String> {
        val list = mutableListOf<String>()
        val tokens = input.split(",").map { it.trim() }
        for (token in tokens) {
            if (token.contains("/")) {
                // شبیه‌سازی بسیار ساده برای رنج CIDR /24
                val base = token.substringBeforeLast(".")
                for (i in 1..254) {
                    list.add("$base.$i")
                }
            } else if (token.isNotEmpty()) {
                list.add(token)
            }
        }
        return list
    }
}
