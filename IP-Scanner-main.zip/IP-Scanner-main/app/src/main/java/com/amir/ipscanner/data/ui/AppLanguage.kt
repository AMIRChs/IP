enum class AppLanguage { EN, FA }

object Localization {
    val strings = mapOf(
        AppLanguage.EN to mapOf(
            "title" to "Advanced IP Scanner",
            "ip_range" to "IP List (Comma separated / Subnet)",
            "port" to "Target Port",
            "timeout" to "Timeout (ms)",
            "vless_config" to "VLESS Config / UUID (Optional)",
            "scan" to "Start Scan",
            "scanning" to "Scanning...",
            "stop" to "Stop Scan",
            "status" to "Status",
            "latency" to "Latency",
            "results" to "Scan Results",
            "clean" to "Clean",
            "failed" to "Failed"
        ),
        AppLanguage.FA to mapOf(
            "title" to "آی‌پی اسکنر پیشرفته",
            "ip_range" to "لیست آی‌پی‌ها (جدا شده با کاما یا سابنت)",
            "port" to "پورت هدف",
            "timeout" to "زمان انتظار (میلی‌ثانیه)",
            "vless_config" to "کانفیگ VLESS یا UUID (اختیاری)",
            "scan" to "شروع اسکن",
            "scanning" to "در حال اسکن...",
            "stop" to "توقف اسکن",
            "status" to "وضعیت",
            "latency" to "تاخیر",
            "results" to "نتایج اسکن",
            "clean" to "پاک (تایید شده)",
            "failed" to "ناموفق"
        )
    )

    fun get(key: String, lang: AppLanguage): String {
        return strings[lang]?.[key] ?: key
    }
}
